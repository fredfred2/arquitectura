/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.exceptions;

/**
 *
 * @author parodutt
 */
public class PreexistingEntityException extends Exception {
     public PreexistingEntityException(String message) {
        
     super(message);
    }
}
